# Model

The trained `best_model.hdf5` file is intentionally excluded from this GitHub repository
because it is a large binary file.

Place the model here for local inference:

model/best_model.hdf5

The original training code saves this file as a weights-only Keras checkpoint. The Streamlit
application reconstructs the Xception architecture and then loads these weights.
