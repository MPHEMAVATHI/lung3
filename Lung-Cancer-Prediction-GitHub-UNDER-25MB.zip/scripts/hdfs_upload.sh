#!/bin/bash
set -e

HDFS_ROOT="/user/${USER}/lung_cancer_dataset"

hdfs dfs -mkdir -p "${HDFS_ROOT}/train"
hdfs dfs -mkdir -p "${HDFS_ROOT}/valid"
hdfs dfs -mkdir -p "${HDFS_ROOT}/test"

hdfs dfs -put dataset/train/* "${HDFS_ROOT}/train/" || true
hdfs dfs -put dataset/valid/* "${HDFS_ROOT}/valid/" || true
hdfs dfs -put dataset/test/* "${HDFS_ROOT}/test/" || true

hdfs dfs -ls -R "${HDFS_ROOT}"
